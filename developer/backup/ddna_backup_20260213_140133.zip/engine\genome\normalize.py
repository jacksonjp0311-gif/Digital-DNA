﻿def normalize(value, total):
    return value / total if total > 0 else 0

