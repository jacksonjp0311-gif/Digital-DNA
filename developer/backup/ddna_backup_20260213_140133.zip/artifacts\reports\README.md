# Report Artifacts

Contains versioned DDNA report snapshots and self-verification outputs.

## Contents
- `self_verify_v1_3.json`
- `self_verify_v1_3_1.json`

## Interlinking
- Useful for regression evidence and release sign-off.
- Can be ingested by CI/CD gates or governance dashboards.
