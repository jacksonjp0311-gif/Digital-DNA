def artifact_drift():
    return 0.0