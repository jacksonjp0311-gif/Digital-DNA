def interface_drift():
    return 0.0