def verify_continuity():
    return True