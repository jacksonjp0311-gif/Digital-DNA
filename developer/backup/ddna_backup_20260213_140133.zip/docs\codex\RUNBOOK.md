﻿# CODEX RUNBOOK
## Run
python engine/orchestrator/run_ddna.py

## Verify
- artifacts/last_run.json updated
- ledger/ddna_ledger.jsonl appended
- tests/* can be executed (optional)
