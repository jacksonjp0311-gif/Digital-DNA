def compute_stability(C, D):
    return C - D