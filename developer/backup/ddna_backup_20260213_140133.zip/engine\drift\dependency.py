﻿"""
engine.drift.dependency
Compat wrapper: real dependency drift lives in dependency_graph.py.
"""
def dependency_drift(genome=None):
    return 0.0
