def compare_genomes(g1, g2):
    return len(set(g1).intersection(set(g2)))