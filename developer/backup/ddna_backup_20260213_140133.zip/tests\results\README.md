# Test Result Artifacts

Machine-readable proof artifacts produced by test execution.

## Contents
- `structural_envelope_proof_v1.json`
- `envelope_lock_v1_4.json`

## Interlinking
- Serves as persisted evidence for CI and release gating.
- Complements console test output with durable records.
